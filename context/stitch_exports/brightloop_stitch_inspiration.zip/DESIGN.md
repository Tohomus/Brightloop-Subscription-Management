﻿# Brightloop Semantic Design System (Stitch Spec)
- Mood: High-density FinTech / SaaS Subscription Engine
- Palette: Slate-950 base (#020617), Slate-900 surface (#0f172a), Slate-800 border (#1e293b), Emerald-500 accent (#10b981)
- Typography: Display Sans for headers, Tabular Monospace for currency and dates
- Density: 8/10 (Cockpit density)
- Contrast: WCAG AAA compliant text contrast
